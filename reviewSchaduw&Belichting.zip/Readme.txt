Review overexposure and colorspace please 

Schaduw & Belichting